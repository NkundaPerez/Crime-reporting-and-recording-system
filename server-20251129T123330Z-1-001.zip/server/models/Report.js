// server/models/Report.js
const mongoose = require('mongoose');

const reportSchema = new mongoose.Schema(
  {
    caseId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Case',
      required: [true, 'Case ID is required'],
    },
    title: {
      type: String,
      required: [true, 'Report title is required'],
      trim: true,
    },
    description: {
      type: String,
      trim: true,
      default: '',
    },
    files: [
      {
        name: {
          type: String,
          required: [true, 'File name is required'],
        },
        path: {
          type: String,
          required: [true, 'File path is required'],
        },
        url: {
          type: String,
          required: [true, 'File URL is required'],
        },
        type: {
          type: String,
          enum: ['image', 'pdf', 'docx', 'audio', 'video', 'other'],
          default: 'other',
          required: true,
        },
      },
    ],
    author: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Author is required'],
    },
    status: {
      type: String,
      enum: ['draft', 'submitted', 'approved'],
      default: 'draft',
    },
  },
  {
    timestamps: true,
    // Prevent Mongoose from adding extra fields
    strict: 'throw',
  }
);

// Optional: Index for faster queries
reportSchema.index({ caseId: 1 });
reportSchema.index({ author: 1 });
reportSchema.index({ status: 1 });

module.exports = mongoose.model('Report', reportSchema);