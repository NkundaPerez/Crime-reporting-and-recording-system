// server/models/Case.js
const mongoose = require('mongoose');

const caseSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    trim: true
  },
  type: {
    type: String,
    required: true,
    enum: ['Theft', 'Assault',358, 'Burglary', 'Robbery', 'Vandalism', 'Drug Offense', 'Traffic Violation', 'Other'],
    default: 'Other'
  },
  location: {
    type: {
      type: String,
      enum: ['Point'],
      default: 'Point'
    },
    coordinates: {
      type: [Number], // [lng, lat]
      default: [0, 0]
    }
  },
  status: {
    type: String,
    enum: ['open', 'pending', 'closed'],
    default: 'open'
  },
  reportedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: false // Citizen can report
  },
  reportedByName: {
    type: String,
    trim: true,
    required: false // For citizen reports
  },
  assignedTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: false
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Geo index for location-based queries (e.g., heat map)
caseSchema.index({ location: '2dsphere' });

// Auto-update `updatedAt`
caseSchema.pre('save', function (next) {
  this.updatedAt = Date.now();
  next();
});

// Virtual: Short Case ID (e.g., C-00123)
caseSchema.virtual('shortId').get(function () {
  return `C-${this._id.toString().slice(-6).toUpperCase()}`;
});

// Populate assignedTo and reportedBy
caseSchema.pre(/^find/, function (next) {
  this.populate('assignedTo', 'name email role');
  this.populate('reportedBy', 'name email');
  next();
});

module.exports = mongoose.model('Case', caseSchema);