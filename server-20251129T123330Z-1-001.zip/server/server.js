// server/index.js
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

const app = express();

// ======================
// 1. BODY PARSERS FIRST (MUST BE BEFORE ANY ROUTE)
// ======================
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// ======================
// 2. CORS (after body parsers)
// ======================
app.use(cors());

// ======================
// 3. SERVE UPLOADED FILES
// ======================
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ======================
// 4. ENSURE UPLOAD DIRS
// ======================
const uploadDirs = [
  path.join(__dirname, 'uploads'),
  path.join(__dirname, 'uploads', 'reports'),
  path.join(__dirname, 'uploads', 'evidence'),
  path.join(__dirname, 'uploads', 'statements'),
];

uploadDirs.forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
    console.log(`Created directory: ${dir}`);
  }
});

// ======================
// 5. ROUTES
// ======================
// Multer routes (multipart/form-data) → can go after express.json()
app.use('/api/reports', require('./routes/reports'));
app.use('/api/evidence', require('./routes/evidence'));
app.use('/api/statements', require('./routes/statements'));

// JSON routes (auth, cases, dashboard) → use express.json()
app.use('/api/auth', require('./routes/auth'));
app.use('/api/cases', require('./routes/cases'));
app.use('/api/dashboard', require('./routes/dashboard'));

// ======================
// 6. SILENCE REACT-DEVTOOLS
// ======================
app.use((req, res, next) => {
  if (
    req.query.pa ||
    req.path.includes('<pre') ||
    req.path.includes('source-map') ||
    req.path.includes('__webpack')
  ) {
    return res.status(200).send('');
  }
  next();
});

// ======================
// 7. PRODUCTION BUILD
// ======================
if (process.env.NODE_ENV === 'production') {
  const buildPath = path.join(__dirname, '../crime/build');
  app.use(express.static(buildPath));

  app.get('*', (req, res) => {
    res.sendFile(path.join(buildPath, 'index.html'));
  });
}

// ======================
// 8. 404 HANDLER
// ======================
app.use((req, res) => {
  res.status(404).json({ msg: 'Route not found' });
});

// ======================
// 9. GLOBAL ERROR HANDLER
// ======================
app.use((err, req, res, next) => {
  console.error('Server Error:', err);
  res.status(err.status || 500).json({
    msg: 'Server error',
    error: process.env.NODE_ENV === 'development' ? err.message : {}
  });
});

// ======================
// 10. START SERVER + DB
// ======================
const PORT = process.env.PORT || 5000;

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => {
    console.log('MongoDB Connected Successfully');
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
      console.log(`API Base URL: http://localhost:${PORT}/api`);
      if (process.env.NODE_ENV === 'production') {
        console.log(`Frontend: http://localhost:${PORT}`);
      }
    });
  })
  .catch(err => {
    console.error('MongoDB Connection Failed');
    console.error('Error:', err.message);
    console.error('Check your .env MONGO_URI');
    console.error('Ensure MongoDB is running');
    process.exit(1);
  });