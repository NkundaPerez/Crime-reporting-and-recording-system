const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const auth = require('../middleware/auth');
const Statement = require('../models/Statement');
const Case = require('../models/Case');

// ───── Multer Config ─────
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/statements/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB max
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|pdf|mp3|wav|mp4|mov/;
    const ext = path.extname(file.originalname).toLowerCase();
    const mimetype = allowed.test(file.mimetype);
    const extname = allowed.test(ext);
    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error('Invalid file type. Allowed: images, PDF, audio, video'));
  }
});

// ───── GET /api/statements – List with filters & pagination ─────
router.get('/', auth, async (req, res) => {
  const { case: caseId, search, page = 1, limit = 10, type, status } = req.query;
  const skip = (page - 1) * limit;

  const query = {};
  if (caseId) query.caseId = caseId;
  if (type) query.type = type;
  if (status) query.status = status;
  if (search) {
    query.$or = [
      { personName: { $regex: search, $options: 'i' } },
      { narrative: { $regex: search, $options: 'i' } }
    ];
  }

  try {
    const total = await Statement.countDocuments(query);
    const statements = await Statement.find(query)
      .populate('caseId', 'title _id')
      .populate('author', 'name')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    res.json({
      statements,
      pagination: {
        current: parseInt(page),
        pages: Math.ceil(total / limit),
        total,
        hasNext: parseInt(page) < Math.ceil(total / limit),
        hasPrev: parseInt(page) > 1
      }
    });
  } catch (err) {
    console.error('GET /statements error:', err);
    res.status(500).json({ msg: 'Failed to load statements' });
  }
});

// ───── POST /api/statements – Create new statement with files ─────
router.post('/', auth, upload.array('files'), async (req, res) => {
  try {
    const { caseId, personName, type, officer, narrative, status } = req.body;

    // Required fields
    if (!caseId || !personName || !narrative?.trim()) {
      return res.status(400).json({ msg: 'Case, Person Name, and Narrative are required' });
    }

    // Validate case exists
    const caseDoc = await Case.findById(caseId);
    if (!caseDoc) {
      return res.status(404).json({ msg: 'Case not found' });
    }

    // Build files array
    const files = req.files?.map(file => ({
      name: file.originalname,
      path: file.path,
      url: `/uploads/statements/${file.filename}`
    })) || [];

    // Create statement
    const statement = new Statement({
      caseId,
      personName,
      type: type || 'witness',
      officer: officer || '',
      narrative: narrative.trim(),
      status: status || 'pending',
      author: req.user.id,
      files
    });

    await statement.save();
    await statement.populate('caseId', 'title _id');
    await statement.populate('author', 'name');

    res.status(201).json(statement);
  } catch (err) {
    console.error('POST /statements error:', err);
    res.status(500).json({ msg: 'Server error' });
  }
});

// ───── PATCH /api/statements/:id – Edit narrative (author or admin) ─────
router.patch('/:id', auth, async (req, res) => {
  const { narrative } = req.body;

  try {
    const stmt = await Statement.findById(req.params.id);
    if (!stmt) return res.status(404).json({ msg: 'Statement not found' });

    // Authorization
    const isAuthor = stmt.author.toString() === req.user.id;
    const isAdmin = req.user.role === 'admin';
    if (!isAuthor && !isAdmin) {
      return res.status(403).json({ msg: 'Access denied' });
    }

    if (narrative?.trim()) {
      stmt.narrative = narrative.trim();
      stmt.updatedAt = Date.now();
    }

    await stmt.save();
    await stmt.populate('caseId', 'title _id');
    await stmt.populate('author', 'name');

    res.json(stmt);
  } catch (err) {
    console.error('PATCH /statements error:', err);
    res.status(400).json({ msg: 'Failed to update' });
  }
});

// ───── DELETE /api/statements/:id – Delete (author or admin) ─────
router.delete('/:id', auth, async (req, res) => {
  try {
    const stmt = await Statement.findById(req.params.id);
    if (!stmt) return res.status(404).json({ msg: 'Not found' });

    const isAuthor = stmt.author.toString() === req.user.id;
    const isAdmin = req.user.role === 'admin';
    if (!isAuthor && !isAdmin) {
      return res.status(403).json({ msg: 'Access denied' });
    }

    // Optional: Delete files from disk
    // stmt.files.forEach(f => fs.unlinkSync(f.path));

    await stmt.deleteOne();
    res.json({ msg: 'Statement deleted' });
  } catch (err) {
    console.error('DELETE /statements error:', err);
    res.status(500).json({ msg: 'Server error' });
  }
});

module.exports = router;