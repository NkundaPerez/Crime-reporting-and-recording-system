// server/routes/dashboard.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Case = require('../models/Case');
const User = require('../models/User');

/**
 * GET /api/dashboard
 * Protected route – works for both admin & officer
 */
router.get('/', auth, async (req, res) => {
  try {
    // ───── 1. Case status counts ─────
    const [open, pending, closed] = await Promise.all([
      Case.countDocuments({ status: 'open' }),
      Case.countDocuments({ status: 'pending' }),
      Case.countDocuments({ status: 'closed' })
    ]);

    // ───── 2. Crime rate by month (last 12 months) ─────
    const twelveMonthsAgo = new Date();
    twelveMonthsAgo.setMonth(twelveMonthsAgo.getMonth() - 11);

    const crimeRateByPeriod = await Case.aggregate([
      {
        $match: { createdAt: { $gte: twelveMonthsAgo } }
      },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m', date: '$createdAt' } },
          count: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    // Fill missing months with 0 (optional but looks better on chart)
    const filledLabels = [];
    const filledData = [];
    const now = new Date();
    for (let i = 11; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const label = d.toISOString().slice(0, 7); // YYYY-MM
      filledLabels.push(label);

      const found = crimeRateByPeriod.find(x => x._id === label);
      filledData.push(found ? found.count : 0);
    }

    // ───── 3. Crime type distribution ─────
    const crimeTypeDistribution = await Case.aggregate([
      { $group: { _id: '$type', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 10 }
    ]);

    // ───── 4. Heat-map data (only valid coordinates) ─────
    const heatMapData = await Case.find({
      'location.coordinates': { 
        $exists: true, 
        $ne: null,
        $not: { $eq: [0, 0] }
      }
    })
      .select('location.coordinates -_id')
      .limit(500)
      .lean();

    const coordinates = heatMapData
      .map(c => c.location?.coordinates)
      .filter(Boolean);

    // ───── 5. Officer Stats (Safe & Fast) ─────
    const totalOfficers = await User.countDocuments({ role: 'officer' });

    // Count officers currently assigned to active cases
    const activeCases = await Case.distinct('assignedTo', {
      status: { $in: ['open', 'pending'] },
      assignedTo: { $exists: true, $ne: null }
    });

    const assignedOfficers = activeCases.filter(id => id != null).length;
    const availableOfficers = totalOfficers - assignedOfficers;

    // ───── 6. Final Response ─────
    res.json({
      cases: { open, pending, closed },
      crimeRateByPeriod: {
        labels: filledLabels,
        data: filledData
      },
      crimeTypeDistribution: {
        labels: crimeTypeDistribution.map(x => x._id || 'Unknown'),
        data: crimeTypeDistribution.map(x => x.count)
      },
      heatMapData: coordinates,
      officers: {
        total: totalOfficers,
        assigned: assignedOfficers,
        available: availableOfficers
      }
    });

  } catch (err) {
    console.error('Dashboard error:', err.message);
    res.status(500).json({ msg: 'Failed to load dashboard data' });
  }
});

module.exports = router;