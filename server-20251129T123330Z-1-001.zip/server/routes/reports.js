// server/routes/reports.js
const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const auth = require('../middleware/auth');
const Report = require('../models/Report');
const Case = require('../models/Case');

// ======================
// ENSURE UPLOAD DIR
// ======================
const uploadDir = path.join(__dirname, '..', 'uploads', 'reports');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
  console.log('Created:', uploadDir);
}

// ======================
// MULTER CONFIG
// ======================
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, `report-${unique}${path.extname(file.originalname)}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
  fileFilter: (req, file, cb) => {
    const allowed = /pdf|docx|doc|jpe?g|png|gif|mp3|wav|mp4|mov/i;
    const ext = path.extname(file.originalname);
    if (allowed.test(ext)) {
      cb(null, true);
    } else {
      cb(new Error(`File type ${ext} not allowed`));
    }
  },
});

// ======================
// FILE TYPE HELPER
// ======================
const getFileType = (filename) => {
  const ext = path.extname(filename).toLowerCase();
  if (['.jpg', '.jpeg', '.png', '.gif'].includes(ext)) return 'image';
  if (['.pdf'].includes(ext)) return 'pdf';
  if (['.doc', '.docx'].includes(ext)) return 'docx';
  if (['.mp3', '.wav'].includes(ext)) return 'audio';
  if (['.mp4', '.mov'].includes(ext)) return 'video';
  return 'other';
};

// ======================
// SILENCE REACT-DEVTOOLS PING
// ======================
router.use((req, res, next) => {
  if (req.query.pa || req.path.includes('<pre') || req.path.includes('source-map')) {
    return res.status(200).json({ ok: true });
  }
  next();
});

// ======================
// GET /api/reports
// ======================
router.get('/', auth, async (req, res) => {
  let { case: caseId, caseId: caseIdAlt, page = 1, limit = 10 } = req.query;
  caseId = caseId || caseIdAlt;
  const skip = (parseInt(page) - 1) * parseInt(limit);
  const query = {};

  if (caseId) query.caseId = caseId;

  if (req.user.role !== 'admin') {
    const userCases = await Case.find({ officerInCharge: req.user.id }).select('_id');
    const caseIds = userCases.map(c => c._id.toString());

    if (caseId && !caseIds.includes(caseId)) {
      return res.status(403).json({ msg: 'Access denied' });
    }
    query.caseId = { $in: caseIds };
  }

  try {
    const total = await Report.countDocuments(query);
    const reports = await Report.find(query)
      .populate('caseId', 'title _id')
      .populate('author', 'name email')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    res.json({
      reports,
      pagination: {
        current: parseInt(page),
        pages: Math.ceil(total / parseInt(limit)),
        total,
      },
    });
  } catch (err) {
    console.error('GET /reports error:', err);
    res.status(500).json({ msg: 'Server error' });
  }
});

// ======================
// POST /api/reports – 100% SAFE (NO CastError)
// ======================
router.post(
  '/',
  auth,
  (req, res, next) => {
    upload.array('files', 10)(req, res, (err) => {
      if (err instanceof multer.MulterError) {
        return res.status(400).json({ msg: err.message });
      }
      if (err) {
        console.error('Multer error:', err.message);
        return res.status(400).json({ msg: err.message });
      }
      next();
    });
  },
  async (req, res) => {
    try {
      console.log('Upload payload:', {
        body: req.body,
        filesCount: req.files?.length,
      });

      const { caseId, title, description, status } = req.body;

      if (!caseId || !title?.trim()) {
        return res.status(400).json({ msg: 'Case and title are required' });
      }

      const caseDoc = await Case.findById(caseId);
      if (!caseDoc) return res.status(404).json({ msg: 'Case not found' });

      if (req.user.role !== 'admin' && caseDoc.officerInCharge.toString() !== req.user.id) {
        return res.status(403).json({ msg: 'Not authorized' });
      }

      // CRITICAL: ENSURE ONLY STRINGS ARE SAVED
      const files = (req.files || []).map(f => ({
        name: String(f.originalname),
        path: String(f.path),
        url: String(`/uploads/reports/${path.basename(f.path)}`),
        type: String(getFileType(f.originalname)),
      }));

      const report = new Report({
        caseId,
        title: title.trim(),
        description: description?.trim() || '',
        files,
        author: req.user.id,
        status: ['draft', 'submitted', 'approved'].includes(status) ? status : 'draft',
      });

      await report.save();
      await report.populate('caseId', 'title _id');
      await report.populate('author', 'name email');

      console.log('Report saved:', report._id);
      res.status(201).json(report);
    } catch (err) {
      console.error('POST /reports error:', err);
      res.status(500).json({ msg: 'Upload failed', error: err.message });
    }
  }
);

// ======================
// PATCH /api/reports/:id
// ======================
router.patch('/:id', auth, async (req, res) => {
  try {
    const report = await Report.findById(req.params.id);
    if (!report) return res.status(404).json({ msg: 'Report not found' });

    if (req.user.role !== 'admin' && report.author.toString() !== req.user.id) {
      return res.status(403).json({ msg: 'Access denied' });
    }

    const { title, description, status } = req.body;

    if (title?.trim()) report.title = title.trim();
    if (description !== undefined) report.description = description?.trim() || '';
    if (['draft', 'submitted', 'approved'].includes(status)) {
      report.status = status;
    }

    await report.save();
    await report.populate('caseId', 'title _id');
    await report.populate('author', 'name email');

    res.json(report);
  } catch (err) {
    console.error('PATCH /reports error:', err);
    res.status(500).json({ msg: 'Update failed' });
  }
});

module.exports = router;